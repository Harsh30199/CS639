#run.sh
python ./Source/Assign.py $1